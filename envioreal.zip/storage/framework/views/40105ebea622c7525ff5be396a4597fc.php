<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $user->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user->name)]); ?>
    <div class="flex flex-col gap-8">

        
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div style="flex-shrink:0; width:4rem; height:4rem; border-radius:9999px; overflow:hidden;">
                <img src="<?php echo e(asset('storage/' . ($user->profile_picture ?: 'default-profile.png'))); ?>" alt="<?php echo e($user->name); ?>" style="width:100%; height:100%; object-fit:cover;" />
            </div>
            <div>
                <h1 class="text-2xl font-bold tracking-tight"><?php echo e($user->name); ?></h1>
                <p class="text-sm text-zinc-500 dark:text-zinc-400"><?php echo e($user->username); ?></p>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($media !== null): ?>
            <div style="display:flex; justify-content:space-between; padding:1rem 0; border-bottom:1px solid rgb(228 228 231);" class="dark:border-zinc-700">
                <div class="text-center">
                    <div class="text-4xl font-bold tabular-nums" style="color:rgb(23,221,98)">
                        <?php echo e(rtrim(rtrim(number_format($mediana, 2, '.', ''), '0'), '.')); ?>

                    </div>
                    <div class="text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400 mt-1">Mediana</div>
                </div>
                <div class="text-center">
                    <div class="text-4xl font-bold tabular-nums" style="color:rgb(23,221,98)">
                        <?php echo e(rtrim(rtrim(number_format($media, 2, '.', ''), '0'), '.')); ?>

                    </div>
                    <div class="text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400 mt-1">Média</div>
                </div>
                <div class="text-center">
                    <div class="text-4xl font-bold tabular-nums" style="color:rgb(23,221,98)"><?php echo e($moda); ?></div>
                    <div class="text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400 mt-1">Moda</div>
                </div>
            </div>
        <?php else: ?>
            <p class="text-sm text-zinc-500 dark:text-zinc-400">Ainda sem reviews.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user->reviews->isNotEmpty()): ?>
            <div class="flex flex-col gap-4">
                <h2 class="text-lg font-semibold">Reviews</h2>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $user->reviews->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('movies.show', $review->movie->slug)); ?>" wire:navigate class="block">
                        <div class="rounded-lg border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 p-4 transition-colors"
                             style="border-left:4px solid rgb(0,123,24)">
                            <div style="display:flex; align-items:flex-start; gap:1rem;">

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($review->movie->poster): ?>
                                    <div style="flex-shrink:0; width:3rem; height:4.5rem; overflow:hidden; border-radius:0.375rem;">
                                        <img src="<?php echo e(asset('storage/' . $review->movie->poster)); ?>"
                                             alt="<?php echo e($review->movie->title); ?>"
                                             style="width:100%; height:100%; object-fit:cover;" />
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                <div style="flex:1; min-width:0;">
                                    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:0.375rem;">
                                        <span class="font-semibold text-sm truncate"><?php echo e($review->movie->title); ?></span>
                                        <span class="text-sm font-bold tabular-nums flex-shrink-0 ml-4" style="color:rgb(23,221,98)">
                                            ★ <?php echo e(number_format($review->rating, 1)); ?>

                                        </span>
                                    </div>
                                    <p class="text-sm text-zinc-700 dark:text-zinc-300 leading-relaxed"><?php echo e($review->content); ?></p>
                                    <p class="text-xs text-zinc-400 dark:text-zinc-500 mt-2"><?php echo e($review->created_at->format('d/m/Y')); ?></p>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\Users\gabri\Desktop\cinemanso\cinemanso\resources\views/users/show.blade.php ENDPATH**/ ?>