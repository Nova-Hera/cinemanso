<?php

use App\Models\Movie;
use App\Models\User;
use Livewire\Attributes\On;
use Livewire\Volt\Component;

?>

<div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($open): ?>
        <div
            class="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4"
            @keydown.escape.window="$wire.close()"
        >
            <div class="absolute inset-0 bg-black/60" wire:click="close"></div>

            <div class="relative w-full max-w-lg rounded-xl bg-white dark:bg-zinc-900 shadow-2xl border border-zinc-200 dark:border-zinc-700 overflow-hidden">
                <div class="p-4 border-b border-zinc-200 dark:border-zinc-700">
                    <input
                        type="text"
                        wire:model.live.debounce.200ms="query"
                        placeholder="Buscar filmes ou usuários..."
                        class="w-full rounded-lg bg-zinc-100 dark:bg-zinc-800 border-0 px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-green-500 placeholder:text-zinc-400"
                        x-init="$el.focus()"
                    />
                </div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(strlen(trim($query)) >= 2): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($movies) && empty($users)): ?>
                        <div class="p-6 text-center text-sm text-zinc-400">Nenhum resultado encontrado.</div>
                    <?php else: ?>
                        <div class="max-h-96 overflow-y-auto divide-y divide-zinc-100 dark:divide-zinc-800">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($movies)): ?>
                                <div class="px-4 py-2">
                                    <p class="text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400 mb-1">Filmes</p>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('movies.show', $movie['slug'])); ?>" wire:navigate wire:click="close"
                                           class="flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($movie['poster']): ?>
                                                <img src="<?php echo e(asset('storage/' . $movie['poster'])); ?>" alt="<?php echo e($movie['title']); ?>" class="h-10 w-7 rounded object-cover flex-shrink-0" />
                                            <?php else: ?>
                                                <div class="h-10 w-7 rounded bg-zinc-200 dark:bg-zinc-700 flex-shrink-0"></div>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <span class="text-sm font-medium truncate flex-1"><?php echo e($movie['title']); ?></span>
                                            <?php
                                                $sb = match($movie['status']) {
                                                    'watched'   => ['label' => 'Visto',      'style' => 'background:rgb(23,221,98);color:#000'],
                                                    'watching'  => ['label' => 'Assistindo', 'style' => 'background:rgb(217,119,6);color:#fff'],
                                                    'watchlist' => ['label' => 'Watchlist',  'style' => 'background:rgb(82,82,91);color:#fff'],
                                                    default     => null,
                                                };
                                            ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($sb): ?>
                                                <span style="<?php echo e($sb['style']); ?>; border-radius:9999px; padding:0.125rem 0.5rem; font-size:0.7rem; font-weight:600; flex-shrink:0;">
                                                    <?php echo e($sb['label']); ?>

                                                </span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($users)): ?>
                                <div class="px-4 py-2">
                                    <p class="text-xs font-semibold uppercase tracking-wide text-zinc-500 dark:text-zinc-400 mb-1">Usuários</p>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('users.show', $user['username'])); ?>" wire:navigate wire:click="close"
                                           class="flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors">
                                            <img src="<?php echo e(asset('storage/' . ($user['profile_picture'] ?: 'default-profile.png'))); ?>" alt="<?php echo e($user['name']); ?>" class="h-8 w-8 rounded-full object-cover flex-shrink-0" />
                                            <div class="min-w-0">
                                                <p class="text-sm font-medium truncate"><?php echo e($user['name']); ?></p>
                                                <p class="text-xs text-zinc-400 truncate"><?php echo e($user['username']); ?></p>
                                            </div>
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php else: ?>
                    <div class="p-4 text-center text-sm text-zinc-400">O Xbox series X é como um geladeira moderna: é onde tem tudo q vc gosta e deicha sua comida mais preservada e saborosa.</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div><?php /**PATH C:\Users\gabri\Desktop\cinemanso\cinemanso\resources\views\livewire/search-modal.blade.php ENDPATH**/ ?>