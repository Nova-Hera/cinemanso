<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Filmes')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Filmes'))]); ?>
    <div class="flex flex-col gap-6">

        <div class="flex items-center justify-between">
            <h1 class="text-2xl font-bold tracking-tight">Filmes</h1>
            <form method="GET" action="<?php echo e(route('movies.index')); ?>" class="flex items-center gap-2">
                <select name="status" onchange="this.form.submit()"
                        style="background:transparent; border:1px solid rgb(161,161,170); border-radius:0.5rem; padding:0.4rem 0.75rem; font-size:0.875rem; color:inherit; cursor:pointer;">
                    <option style="color:black" value="" <?php if(!$currentStatus): echo 'selected'; endif; ?>>Todos</option>
                    <option style="color:black" value="watchlist" <?php if($currentStatus === 'watchlist'): echo 'selected'; endif; ?>>Watchlist</option>
                    <option style="color:black" value="watching"  <?php if($currentStatus === 'watching'): echo 'selected'; endif; ?>>Assistindo</option>
                    <option style="color:black" value="watched"   <?php if($currentStatus === 'watched'): echo 'selected'; endif; ?>>Visto</option>
                </select>
                <select name="sort" onchange="this.form.submit()"
                        style="background:transparent; border:1px solid rgb(161,161,170); border-radius:0.5rem; padding:0.4rem 0.75rem; font-size:0.875rem; color:inherit; cursor:pointer;">
                    <option style="color:black" value="title"   <?php if($currentSort === 'title'): echo 'selected'; endif; ?>>Alfabético</option>
                    <option style="color:black" value="media"   <?php if($currentSort === 'media'): echo 'selected'; endif; ?>>Média</option>
                    <option style="color:black" value="mediana" <?php if($currentSort === 'mediana'): echo 'selected'; endif; ?>>Mediana</option>
                    <option style="color:black" value="moda"    <?php if($currentSort === 'moda'): echo 'selected'; endif; ?>>Moda</option>
                </select>
            </form>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($movies->isEmpty()): ?>
            <div class="flex flex-col items-center justify-center py-24 gap-3 text-zinc-400">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
                </svg>
                <p class="text-lg">Nenhum filme por aqui ainda.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $ratingValues = $movie->reviews->pluck('rating');
                        $displayRating = null;
                        if ($ratingValues->isNotEmpty()) {
                            $displayRating = match($currentSort) {
                                'mediana' => (function() use ($ratingValues) {
                                    $s = $ratingValues->sort()->values();
                                    $c = $s->count(); $mid = (int)($c / 2);
                                    return $c % 2 === 0 ? ($s[$mid-1] + $s[$mid]) / 2 : $s[$mid];
                                })(),
                                'moda'    => $ratingValues->countBy()->sortDesc()->keys()->first(),
                                default   => round($ratingValues->avg(), 2),
                            };
                        }
                    ?>
                    <?php if (isset($component)) { $__componentOriginal55397d6368ec190d69af3e6924d8cf5e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal55397d6368ec190d69af3e6924d8cf5e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.movie-card','data' => ['id' => $movie->slug,'title' => $movie->title,'image' => $movie->poster,'status' => $movie->status,'rating' => $displayRating,'wireNavigate' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('movie-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movie->slug),'title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movie->title),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movie->poster),'status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($movie->status),'rating' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($displayRating),'wire-navigate' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal55397d6368ec190d69af3e6924d8cf5e)): ?>
<?php $attributes = $__attributesOriginal55397d6368ec190d69af3e6924d8cf5e; ?>
<?php unset($__attributesOriginal55397d6368ec190d69af3e6924d8cf5e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal55397d6368ec190d69af3e6924d8cf5e)): ?>
<?php $component = $__componentOriginal55397d6368ec190d69af3e6924d8cf5e; ?>
<?php unset($__componentOriginal55397d6368ec190d69af3e6924d8cf5e); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\Users\gabri\Desktop\cinemanso\cinemanso\resources\views/movies/index.blade.php ENDPATH**/ ?>