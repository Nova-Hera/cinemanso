<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id'           => null,
    'title'        => null,
    'image'        => null,
    'status'       => null,
    'rating'       => null,
    'wireNavigate' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id'           => null,
    'title'        => null,
    'image'        => null,
    'status'       => null,
    'rating'       => null,
    'wireNavigate' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $src = $image ? asset('storage/' . $image) : null;

    $badge = match ($status) {
        'watched'   => ['label' => 'Visto',      'style' => 'background:rgb(23,221,98);color:#000'],
        'watching'  => ['label' => 'Assistindo', 'style' => 'background:rgb(217,119,6);color:#fff'],
        'watchlist' => ['label' => 'Watchlist',  'style' => 'background:rgb(82,82,91);color:#fff'],
        default     => null,
    };

    $ratingColor = null;
    if ($rating !== null) {
        $r = (float)$rating;
        if ($r <= 5) {
            $t = $r / 5;
            $ratingColor = sprintf('rgb(%d,%d,%d)',
                (int)(239 + $t * (234 - 239)),
                (int)(68  + $t * (115 - 68)),
                (int)(68  + $t * (8   - 68)));
        } else {
            $t = ($r - 5) / 5;
            $ratingColor = sprintf('rgb(%d,%d,%d)',
                (int)(234 + $t * (23  - 234)),
                (int)(115 + $t * (221 - 115)),
                (int)(8   + $t * (98  - 8)));
        }
    }
?>

<a href="<?php echo e(route('movies.show', ['movie' => $id])); ?>"
   <?php if($wireNavigate): ?> wire:navigate <?php endif; ?>
   class="group block">
    <div style="position:relative; aspect-ratio:2/3; overflow:hidden; border-radius:0.75rem; border:1px solid rgb(228,228,231); transition:all 200ms ease;"
         class="dark:border-zinc-700 group-hover:shadow-lg group-hover:scale-[1.02]">

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($src): ?>
            <img src="<?php echo e($src); ?>" alt="<?php echo e($title); ?>"
                 style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover;" />
        <?php else: ?>
            <div style="position:absolute; inset:0; display:flex; align-items:center; justify-content:center; background:rgb(39,39,42);">
                <svg xmlns="http://www.w3.org/2000/svg" style="height:3rem; width:3rem; color:rgb(82,82,91);" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
                </svg>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($ratingColor): ?>
            <span style="position:absolute; top:0.5rem; left:0.5rem; border-radius:9999px; padding:0.125rem 0.45rem; font-size:0.72rem; font-weight:700; background:<?php echo e($ratingColor); ?>; color:#000;">
                <?php echo e(number_format((float)$rating, 1)); ?>

            </span>
        <?php else: ?>
            <span style="position:absolute; top:0.5rem; left:0.5rem; border-radius:9999px; padding:0.2rem; background:rgba(0,0,0,0.45); display:flex; align-items:center; justify-content:center;">
                <svg xmlns="http://www.w3.org/2000/svg" style="width:0.8rem; height:0.8rem; color:#fff;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
                </svg>
            </span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($badge): ?>
            <span style="position:absolute; top:0.5rem; right:0.5rem; border-radius:9999px; padding:0.125rem 0.5rem; font-size:0.75rem; font-weight:600; <?php echo e($badge['style']); ?>">
                <?php echo e($badge['label']); ?>

            </span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div style="position:absolute; bottom:0; left:0; width:100%; background:linear-gradient(to top, rgba(0,0,0,0.8), transparent); padding:0.75rem;">
            <h3 style="color:#fff; font-size:0.875rem; font-weight:600; line-height:1.25; overflow:hidden; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical;"><?php echo e($title); ?></h3>
        </div>
    </div>
</a>
<?php /**PATH C:\Users\gabri\Desktop\cinemanso\cinemanso\resources\views/components/movie-card.blade.php ENDPATH**/ ?>