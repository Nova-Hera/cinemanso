<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'username'     => null,
    'title'        => null,
    'image'        => null,
    'wireNavigate' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'username'     => null,
    'title'        => null,
    'image'        => null,
    'wireNavigate' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<a href="<?php echo e(route('users.show', ['user' => $username])); ?>"
   <?php if($wireNavigate): ?> wire:navigate <?php endif; ?>
   class="group block">
    <div style="position:relative; aspect-ratio:2/3; overflow:hidden; border-radius:0.75rem; border:1px solid rgb(228,228,231); transition:all 200ms ease;"
         class="dark:border-zinc-700 group-hover:shadow-lg group-hover:scale-[1.02]">

        <img
            src="<?php echo e(asset('storage/' . ($image ?: 'default-profile.png'))); ?>"
            alt="<?php echo e($title); ?>"
            style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover;"
        />

        <span style="position:absolute; top:0.5rem; left:0.5rem; border-radius:9999px; padding:0.2rem; background:rgba(0,0,0,0.45); display:flex; align-items:center; justify-content:center;">
            <svg xmlns="http://www.w3.org/2000/svg" style="width:0.8rem; height:0.8rem; color:#fff;" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
        </span>

        <div style="position:absolute; bottom:0; left:0; width:100%; background:linear-gradient(to top, rgba(0,0,0,0.8), transparent); padding:0.75rem;">
            <h3 style="color:#fff; font-size:0.875rem; font-weight:600; line-height:1.25; overflow:hidden; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical;"><?php echo e($title); ?></h3>
            <p style="color:rgba(255,255,255,0.7); font-size:0.75rem; margin-top:0.125rem;"><?php echo e($username); ?></p>
        </div>
    </div>
</a>
<?php /**PATH C:\Users\gabri\Desktop\cinemanso\cinemanso\resources\views/components/user-card.blade.php ENDPATH**/ ?>